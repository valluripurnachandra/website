import React from 'react';
import { Toaster } from 'sonner';
import EventForm from './components/EventForm';
import EventMap from './components/EventMap';
import ContactInfo from './components/ContactInfo';
import EventDetails from './components/EventDetails';

function App() {
  return (
    <div className="min-h-screen bg-black">
      <Toaster position="top-center" />
      
      {/* Video Background */}
      <div className="fixed inset-0 z-0">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover opacity-40"
        >
          <source
            src="https://assets.mixkit.co/videos/preview/mixkit-crowd-of-people-at-a-concert-1462-large.mp4"
            type="video/mp4"
          />
        </video>
      </div>

      {/* Hero Section */}
      <div className="relative min-h-[60vh] flex items-center justify-center z-10">
        <div className="text-center text-white px-4">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text">
            New Year's Eve Festival 2024
          </h1>
          <p className="text-xl md:text-2xl mb-8">
            Join us for the most spectacular celebration of the year
          </p>
          <div className="animate-bounce">
            <span className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full text-white font-semibold">
              Book Your Tickets Now
            </span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left Column */}
          <div className="space-y-8">
            <div className="bg-white/90 backdrop-blur-lg p-8 rounded-lg shadow-xl">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Register Now</h2>
              <EventForm />
            </div>
            <EventDetails />
          </div>

          {/* Right Column */}
          <div className="space-y-8">
            <div className="bg-white/90 backdrop-blur-lg p-8 rounded-lg shadow-xl">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Event Location</h2>
              <EventMap />
            </div>
            <ContactInfo />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;