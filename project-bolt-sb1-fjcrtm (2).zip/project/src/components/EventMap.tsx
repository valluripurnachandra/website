import React from 'react';
import { MapPin } from 'lucide-react';

export default function EventMap() {
  return (
    <div className="w-full h-[400px] relative rounded-lg overflow-hidden">
      <iframe
        title="Event Location"
        width="100%"
        height="100%"
        frameBorder="0"
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2624.9916256937595!2d2.2922926156744847!3d48.858370079287466!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66e2964e34e2d%3A0x8ddca9ee380ef7e0!2sEiffel%20Tower!5e0!3m2!1sen!2sus!4v1647834456925!5m2!1sen!2sus"
        allowFullScreen
        loading="lazy"
      ></iframe>
      <div className="absolute bottom-4 left-4 bg-white p-3 rounded-lg shadow-lg">
        <div className="flex items-center gap-2">
          <MapPin className="w-5 h-5 text-indigo-600" />
          <span className="text-sm font-medium">Event Location</span>
        </div>
      </div>
    </div>
  );
}