export interface EventFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  attendees: number;
  foodPreference: string;
}