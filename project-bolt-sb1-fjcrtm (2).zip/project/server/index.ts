import express from 'express';
import cors from 'cors';
import db from './database.js';

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

// Register new attendee
app.post('/api/register', (req, res) => {
  try {
    const { firstName, lastName, email, phone, attendees, foodPreference } = req.body;

    const stmt = db.prepare(`
      INSERT INTO attendees (firstName, lastName, email, phone, attendees, foodPreference)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    const result = stmt.run(firstName, lastName, email, phone, attendees, foodPreference);

    res.json({
      success: true,
      id: result.lastInsertRowid
    });
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      res.status(400).json({
        success: false,
        error: 'Email already registered'
      });
    } else {
      res.status(500).json({
        success: false,
        error: 'Internal server error'
      });
    }
  }
});

// Get all attendees
app.get('/api/attendees', (req, res) => {
  try {
    const stmt = db.prepare('SELECT * FROM attendees ORDER BY createdAt DESC');
    const attendees = stmt.all();
    res.json(attendees);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});