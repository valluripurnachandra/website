import React from 'react';
import { Calendar, MapPin, Music, Users } from 'lucide-react';

export default function EventDetails() {
  return (
    <div className="space-y-6 bg-gradient-to-r from-purple-500 to-pink-500 p-8 rounded-lg text-white">
      <h2 className="text-3xl font-bold">Festival Highlights</h2>
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <Calendar className="w-6 h-6" />
          <div>
            <p className="font-semibold">Date & Time</p>
            <p>December 31, 2024 - 8:00 PM onwards</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <MapPin className="w-6 h-6" />
          <div>
            <p className="font-semibold">Venue</p>
            <p>Starlight Garden Arena</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Music className="w-6 h-6" />
          <div>
            <p className="font-semibold">Entertainment</p>
            <p>Live DJ, Dance Performances, Fireworks</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Users className="w-6 h-6" />
          <div>
            <p className="font-semibold">Expected Guests</p>
            <p>1000+ Attendees</p>
          </div>
        </div>
      </div>
    </div>
  );
}