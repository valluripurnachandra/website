import React from 'react';
import { Phone, Mail, Clock, MapPin } from 'lucide-react';

export default function ContactInfo() {
  return (
    <div className="space-y-6 bg-gradient-to-r from-indigo-500 to-cyan-500 p-8 rounded-lg text-white">
      <h2 className="text-3xl font-bold">Get in Touch</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <Phone className="w-6 h-6" />
            <div>
              <p className="font-semibold">Call Us</p>
              <p>+1 (555) 123-4567</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Mail className="w-6 h-6" />
            <div>
              <p className="font-semibold">Email Us</p>
              <p>festival@example.com</p>
            </div>
          </div>
        </div>
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <Clock className="w-6 h-6" />
            <div>
              <p className="font-semibold">Office Hours</p>
              <p>10:00 AM - 8:00 PM Daily</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <MapPin className="w-6 h-6" />
            <div>
              <p className="font-semibold">Address</p>
              <p>123 Festival Street, Party City</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}