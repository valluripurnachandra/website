import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Attendee from './models/Attendee.js';
import { sendRegistrationEmail } from './utils/mailer.js';

dotenv.config();

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose.connect('mongodb+srv://pandugaadu8247:Purna123@cluster0.tkwoy.mongodb.net/eventdb')
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => console.error('MongoDB connection error:', err));

// Register new attendee
app.post('/api/register', async (req, res) => {
  try {
    const attendee = new Attendee(req.body);
    await attendee.save();
    
    // Send email notification
    await sendRegistrationEmail(req.body);

    res.json({
      success: true,
      id: attendee._id
    });
  } catch (error) {
    if (error.code === 11000) {
      res.status(400).json({
        success: false,
        error: 'Email already registered'
      });
    } else {
      res.status(500).json({
        success: false,
        error: 'Internal server error'
      });
    }
  }
});

// Get all attendees
app.get('/api/attendees', async (req, res) => {
  try {
    const attendees = await Attendee.find().sort({ createdAt: -1 });
    res.json(attendees);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});