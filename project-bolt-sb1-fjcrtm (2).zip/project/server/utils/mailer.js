import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'pandugaadu8247@gmail.com',
    pass: process.env.EMAIL_PASSWORD // You'll need to set this up with an app password
  }
});

export const sendRegistrationEmail = async (attendeeData) => {
  const mailOptions = {
    from: 'pandugaadu8247@gmail.com',
    to: 'pandugaadu8247@gmail.com',
    subject: 'New Event Registration',
    html: `
      <h2>New Registration Details</h2>
      <p><strong>Name:</strong> ${attendeeData.firstName} ${attendeeData.lastName}</p>
      <p><strong>Email:</strong> ${attendeeData.email}</p>
      <p><strong>Phone:</strong> ${attendeeData.phone}</p>
      <p><strong>Number of Attendees:</strong> ${attendeeData.attendees}</p>
      <p><strong>Food Preference:</strong> ${attendeeData.foodPreference}</p>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('Registration notification email sent');
  } catch (error) {
    console.error('Error sending email:', error);
  }
};